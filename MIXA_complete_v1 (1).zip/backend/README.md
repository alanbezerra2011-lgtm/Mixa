# Backend necessário para produção

Serviços recomendados:
- autenticação de usuários;
- banco de dados;
- armazenamento de projetos;
- catálogo e busca;
- sincronização de playlists;
- processamento assíncrono de exportações;
- créditos/limites de IA;
- pagamentos e assinaturas;
- painel administrativo;
- moderação e denúncias;
- analytics.

## Música comercial
O MIXA não deve copiar, baixar ou redistribuir catálogos de terceiros sem licença.
É necessário contratar/licenciar o catálogo adequado e definir direitos de streaming, offline e remix.

## IA
O backend deve chamar um provedor/modelo de IA musical somente com direitos e termos compatíveis com o produto. Não usar vozes ou músicas protegidas sem autorização.
