# MIXA — Roadmap de produto

## Concluído nesta base
- Navegação Android/iOS
- Home
- Biblioteca
- Studio
- Trilhas
- Volume/pan/mute/solo
- BPM
- Estrutura de motor de áudio nativo
- Premium

## Implementação necessária antes da loja
1. Motor DSP real e renderização realtime.
2. Importação de WAV/MP3/M4A.
3. Gravação de microfone e monitoramento.
4. Waveform e timeline editável.
5. Cortar, mover, duplicar e loop.
6. EQ, compressor, gate, reverb e delay.
7. Bounce/export real para WAV/MP3.
8. Player em segundo plano.
9. Backend e sincronização.
10. Catálogo musical devidamente licenciado.
11. IA com backend, créditos e filtros de direitos.
12. Assinaturas oficiais.
13. Privacidade, termos, consentimentos e exclusão de conta.
14. Testes em aparelhos reais.
15. Publicação Google Play e App Store.

## Critério de lançamento
Não publicar como serviço de streaming global até que os direitos do catálogo estejam contratados e os testes de áudio, pagamentos e privacidade estejam aprovados.
