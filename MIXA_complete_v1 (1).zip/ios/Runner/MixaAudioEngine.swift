import AVFoundation

final class MixaAudioEngine {
    private let engine = AVAudioEngine()
    private let mixer: AVAudioMixerNode

    init() {
        mixer = engine.mainMixerNode
    }

    func start() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .default,
                                options: [.defaultToSpeaker, .allowBluetooth])
        try session.setActive(true)
        try engine.start()
    }

    func stop() {
        engine.stop()
    }

    func masterVolume(_ value: Float) {
        mixer.outputVolume = max(0, min(1, value))
    }
}
