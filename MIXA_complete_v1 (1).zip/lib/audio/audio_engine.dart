import 'dart:async';
import '../models/audio_track.dart';

class AudioEngine {
  final tracks = <AudioTrack>[];
  final _position = StreamController<Duration>.broadcast();
  Duration current = Duration.zero;
  bool playing = false;
  double bpm = 120;

  Stream<Duration> get positionStream => _position.stream;

  Future<void> initialize() async {
    // Ponte para o motor nativo de baixa latência.
  }

  void addTrack(AudioTrack track) => tracks.add(track);

  Future<void> play() async {
    playing = true;
    _position.add(current);
    // TODO: iniciar renderização nativa.
  }

  Future<void> pause() async {
    playing = false;
    // TODO: pausar sem destruir o grafo de áudio.
  }

  Future<void> seek(Duration value) async {
    current = value;
    _position.add(current);
    // TODO: reposicionar fontes.
  }

  void setVolume(AudioTrack t, double v) => t.volume = v.clamp(0, 1);
  void setPan(AudioTrack t, double v) => t.pan = v.clamp(-1, 1);

  Future<void> dispose() async => _position.close();
}
