import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/studio_screen.dart';
import 'screens/library_screen.dart';
import 'screens/premium_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MixaApp());
}

class MixaApp extends StatelessWidget {
  const MixaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MIXA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07070B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFB026FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MixaShell(),
    );
  }
}

class MixaShell extends StatefulWidget {
  const MixaShell({super.key});
  @override
  State<MixaShell> createState() => _MixaShellState();
}

class _MixaShellState extends State<MixaShell> {
  int index = 0;

  final pages = const [
    HomeScreen(),
    StudioScreen(),
    LibraryScreen(),
    PremiumScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), label: 'Studio'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Biblioteca'),
          NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), label: 'Premium'),
        ],
      ),
    );
  }
}
