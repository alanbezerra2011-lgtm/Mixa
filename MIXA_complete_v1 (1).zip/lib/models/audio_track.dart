class AudioTrack {
  final String id;
  final String name;
  double volume;
  double pan;
  bool muted;
  bool solo;

  AudioTrack({
    required this.id,
    required this.name,
    this.volume = 1.0,
    this.pan = 0.0,
    this.muted = false,
    this.solo = false,
  });
}
