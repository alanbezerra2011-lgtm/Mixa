import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Row(children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(colors: [Colors.cyan, Colors.pink, Colors.orange]),
            ),
            child: const Icon(Icons.graphic_eq, size: 30),
          ),
          const SizedBox(width: 14),
          const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('MIXA', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            Text('Ouça. Crie. Mixa.'),
          ]),
        ]),
        const SizedBox(height: 24),
        TextField(
          decoration: InputDecoration(
            hintText: 'Buscar música, artista ou gênero',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white10,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 26),
        const Text('Descubra', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SizedBox(
          height: 150,
          child: Row(children: [
            _tile('Mix do Dia', Icons.auto_awesome),
            const SizedBox(width: 12),
            _tile('Criar música', Icons.add_circle_outline),
          ]),
        ),
        const SizedBox(height: 28),
        const Text('Gêneros', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: ['Pop','Funk','Sertanejo','Rap','Rock','Gospel','MPB','Eletrônica','Jazz','Clássica']
              .map((x) => Chip(label: Text(x))).toList(),
        ),
        const SizedBox(height: 28),
        const Text('Recomendado para você', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        ...['Descobertas da semana','Mix brasileiro','Sua playlist diária'].map(
          (x) => ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const CircleAvatar(child: Icon(Icons.music_note)),
            title: Text(x),
            subtitle: const Text('Catálogo licenciado / independente'),
            trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.play_circle_fill, size: 34)),
          ),
        ),
      ],
    );
  }

  Widget _tile(String title, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF24104F), Color(0xFF86198F)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, size: 38),
          const Spacer(),
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}
