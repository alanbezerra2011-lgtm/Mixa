import 'package:flutter/material.dart';

class LibraryScreen extends StatelessWidget {
  const LibraryScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: const [
      Text('Biblioteca', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      SizedBox(height: 20),
      ListTile(leading: Icon(Icons.favorite), title: Text('Favoritos')),
      ListTile(leading: Icon(Icons.queue_music), title: Text('Playlists')),
      ListTile(leading: Icon(Icons.folder), title: Text('Projetos do Studio')),
      ListTile(leading: Icon(Icons.download), title: Text('Offline')),
    ],
  );
}
