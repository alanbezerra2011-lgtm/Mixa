import 'package:flutter/material.dart';

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(24),
    children: [
      const Icon(Icons.workspace_premium, size: 72),
      const SizedBox(height: 14),
      const Center(child: Text('MIXA PREMIUM', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900))),
      const SizedBox(height: 8),
      const Center(child: Text('Mais música. Mais criação. Mais liberdade.')),
      const SizedBox(height: 24),
      _item('Sem anúncios'),
      _item('Studio completo'),
      _item('Projetos ilimitados'),
      _item('Recursos avançados de IA'),
      _item('Exportação sem limitações'),
      const SizedBox(height: 20),
      const Center(child: Text('R\$ 9,90 / mês', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold))),
      const SizedBox(height: 16),
      FilledButton(onPressed: () {}, child: const Text('Assinar Premium')),
      const SizedBox(height: 8),
      const Text('O checkout deve ser conectado às assinaturas oficiais da App Store e Google Play antes da publicação.', textAlign: TextAlign.center),
    ],
  );

  static Widget _item(String text) => ListTile(
    leading: const Icon(Icons.check_circle),
    title: Text(text),
  );
}
