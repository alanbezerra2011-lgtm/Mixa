import 'package:flutter/material.dart';
import '../audio/audio_engine.dart';
import '../models/audio_track.dart';

class StudioScreen extends StatefulWidget {
  const StudioScreen({super.key});
  @override
  State<StudioScreen> createState() => _StudioScreenState();
}

class _StudioScreenState extends State<StudioScreen> {
  final engine = AudioEngine();
  bool playing = false;
  double bpm = 120;

  @override
  void initState() {
    super.initState();
    engine.initialize();
    engine.addTrack(AudioTrack(id: 'vocal', name: 'Vocal'));
    engine.addTrack(AudioTrack(id: 'beat', name: 'Beat', volume: .8));
    engine.addTrack(AudioTrack(id: 'bass', name: 'Bass', volume: .7));
    engine.addTrack(AudioTrack(id: 'keys', name: 'Keys', volume: .65));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text('MIXA STUDIO', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const Text('Crie, grave e mixe sua música'),
        const SizedBox(height: 18),
        Container(
          height: 180,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(colors: [Color(0xFF111827), Color(0xFF4C1D95)]),
          ),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('TIMELINE', style: TextStyle(letterSpacing: 4)),
            const SizedBox(height: 20),
            IconButton.filled(
              iconSize: 44,
              onPressed: () async {
                if (playing) {
                  await engine.pause();
                } else {
                  await engine.play();
                }
                setState(() => playing = !playing);
              },
              icon: Icon(playing ? Icons.pause : Icons.play_arrow),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        Row(children: [
          const Text('BPM'),
          Expanded(child: Slider(value: bpm, min: 60, max: 200, onChanged: (v) => setState(() => bpm = v))),
          Text(bpm.round().toString()),
        ]),
        ...engine.tracks.map((t) => _track(t)),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.mic), label: const Text('Gravar'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.add), label: const Text('Faixa'))),
        ]),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.auto_awesome), label: const Text('Criar com IA')),
        OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.equalizer), label: const Text('EQ e efeitos')),
        OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.file_download), label: const Text('Exportar WAV / MP3')),
      ],
    );
  }

  Widget _track(AudioTrack t) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(children: [
          Row(children: [
            Expanded(child: Text(t.name, style: const TextStyle(fontWeight: FontWeight.bold))),
            IconButton(onPressed: () => setState(() => t.muted = !t.muted), icon: Icon(t.muted ? Icons.volume_off : Icons.volume_up)),
            IconButton(onPressed: () => setState(() => t.solo = !t.solo), icon: Icon(t.solo ? Icons.headphones : Icons.headphones_outlined)),
          ]),
          Row(children: [
            const Icon(Icons.volume_down),
            Expanded(child: Slider(value: t.volume, onChanged: (v) => setState(() => t.volume = v))),
            const Icon(Icons.volume_up),
          ]),
          Row(children: [
            const Text('L'),
            Expanded(child: Slider(value: t.pan, min: -1, max: 1, onChanged: (v) => setState(() => t.pan = v))),
            const Text('R'),
          ]),
        ]),
      ),
    );
  }
}
